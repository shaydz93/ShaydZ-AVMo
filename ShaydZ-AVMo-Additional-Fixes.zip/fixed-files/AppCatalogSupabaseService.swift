import Foundation
import Combine

/// Service for accessing app catalog data from Supabase
class AppCatalogSupabaseService: ObservableObject {
    static let shared = AppCatalogSupabaseService()
    
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        // Initialize with any necessary dependencies
    }
    
    /// Get all available applications from Supabase
    func getApps() -> AnyPublisher<[AppModel], APIError> {
        // In a real implementation, this would fetch data from Supabase
        return Just(AppModel.mockApps)
            .setFailureType(to: APIError.self)
            .eraseToAnyPublisher()
    }
    
    /// Get apps by category from Supabase
    func getAppsByCategory(category: String) -> AnyPublisher<[AppModel], APIError> {
        return Just(AppModel.mockApps.filter { $0.categories.contains(category) })
            .setFailureType(to: APIError.self)
            .eraseToAnyPublisher()
    }
    
    /// Get app details by ID from Supabase
    func getAppDetails(appId: String) -> AnyPublisher<AppModel, APIError> {
        if let app = AppModel.mockApps.first(where: { $0.id == appId }) {
            return Just(app)
                .setFailureType(to: APIError.self)
                .eraseToAnyPublisher()
        } else {
            return Fail(error: APIError.notFound)
                .eraseToAnyPublisher()
        }
    }
    
    /// Search for apps with query in Supabase
    func searchApps(query: String) -> AnyPublisher<[AppModel], APIError> {
        let lowercasedQuery = query.lowercased()
        let filteredApps = AppModel.mockApps.filter {
            $0.name.lowercased().contains(lowercasedQuery) ||
            $0.description.lowercased().contains(lowercasedQuery) ||
            $0.developer.lowercased().contains(lowercasedQuery)
        }
        
        return Just(filteredApps)
            .setFailureType(to: APIError.self)
            .eraseToAnyPublisher()
    }
    
    /// Get VM sessions for an app from Supabase
    func getVMSessionsForApp(appId: String) -> AnyPublisher<[SupabaseVMSession], APIError> {
        // Mock implementation
        return Just([])
            .setFailureType(to: APIError.self)
            .eraseToAnyPublisher()
    }
}
