import SwiftUI

struct ContentView: View {
    var body: some View {
        // DEBUG MODE: Skip all authentication and show debug interface
        DebugHomeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
